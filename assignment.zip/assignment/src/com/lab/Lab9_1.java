package com.lab;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Lab9_1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		FileInputStream fis;
		FileOutputStream fos;
		String fileName="text1.txt";
		String fileName1="text2.txt";
		fis=new FileInputStream(fileName);
		fos=new FileOutputStream(fileName1);
		int i=fis.read();
		int count=0;
		String st="" +(char)i;
		while(i!=-1) {
			i=fis.read();
			st=st+(char)i;
		}
		for(int j=st.length()-2;j>=0;j--)		
		{
	int k=st.charAt(j);
	    
		fos.write(k);
	
		}
		System.out.println(st);
	}

}

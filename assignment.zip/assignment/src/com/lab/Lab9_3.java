package com.lab;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Lab9_3 {

	public static void main(String[] args) throws IOException,InterruptedException {
		// TODO Auto-generated method stub
     Employee emp[]=new Employee[8];
     emp[1]=new Employee(101,"pavan",50000,"Manager");
     emp[2]=new Employee(102,"raju",35000,"System Associate");
     emp[3]=new Employee(103,"ravi",12000,"Programmer");
     emp[4]=new Employee(104,"mujju",11000,"System Associate");
     emp[5]=new Employee(105,"satti",35000,"Programmer");
     emp[6]=new Employee(106,"radha",4000,"Clerk");
     emp[7]=new Employee(107,"prakash",10000,"System Associate");
	
	File file1=new File("Employee.txt");
	File fout=new File("Employee.txt");
	FileOutputStream toFile;
	toFile=new FileOutputStream("Employee.txt");
	String temp="";
	System.out.println("Writing data into files......");
	for(int i=1;i<=7;i++) {
		temp="";
		temp=temp+emp[i].getEmpId();
		for(int j=0;j<temp.length();j++) {
			
			int k=temp.charAt(j);
			toFile.write(k);
			
		}
		toFile.write(32);
		temp="";
		temp=temp+emp[i].getEmpName();
		for(int j=0;j<temp.length();j++)
		{
			int k=temp.charAt(j);
			toFile.write(k);
		}
		toFile.write(32);
		temp="";
		temp=temp+emp[i].getEmpDesignation();
		for(int j=0;j<temp.length();j++)
		{
			int k=temp.charAt(j);
			toFile.write(k);
		}
		toFile.write(32);
		toFile.write(10);
		
	}
	System.out.println("Retriving data from the file");
	Scanner sc=new Scanner(file1);
	for(int i=1;i<=7;i++) {
		System.out.println(sc.nextLine());
		Thread.sleep(1000);
	}

}

}
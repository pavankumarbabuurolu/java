package com.lab;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lab9_2 {
	
	public static void main(String[] args) throws FileNotFoundException{
		String file="numbers.txt";
		File file1=new File(file);
		Scanner sc=new Scanner(file1);
		String str=sc.nextLine();
		System.out.println("elements in  the file are as follows");
		System.out.println(str);
		
		System.out.println("even numbers are");
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)==',')
			{
				String st1=str.substring(0,i);
				String temp1="";
				temp1=temp1+st1;
				int n1=Integer.parseInt(temp1);
				if(n1%2==0)
				{
					System.out.println(n1);
				}
				for(int k=i+1;k<str.length();k++) {
					if(str.charAt(k)==',')
					{
						String st=str.substring(i+1,k);
						String temp="";
						temp=temp+st;
						int n=Integer.parseInt(temp);
						if(n%2==0)
						{
							System.out.println(n);
						}
						i=k;
					}
				}
			}
		}
		
		int i=str.lastIndexOf(',');
		String temp2=str.substring(i+1,str.length());
		String temp3="";
		temp3=temp3+temp2;
		int n=Integer.parseInt(temp3);
		if(n%2==0) {
			System.out.println(n);
		}
	}

}

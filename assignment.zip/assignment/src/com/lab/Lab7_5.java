package com.lab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Lab7_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no of strings to be entered");
		int n=sc.nextInt();
		ArrayList<String> li=new ArrayList<String>();
		for(int i=0;i<n;i++) {
			li.add((String)sc.next());
		}
Collections.sort(li);
for (String x : li) {
	System.out.println(x);
	
} 
	}

}

package com.lab;

import java.security.GeneralSecurityException;

public class Person {
	String firstname;
	String lastname;
	char gender;
	public Person(String firstname, String lastname, char gender) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
	}
	public Person() {
		super();
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		System.out.println("Person Details:");
		System.out.println("");
		System.out.println("____________");
		System.out.println("");
		System.out.println("First Name:"+firstname );
		System.out.println("Last Name:"+lastname);
		System.out.println("Gender:"+gender);
		
		
		return "" ;
	}
	
	  
	
	

	}



package com.lab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the first name:");
		    try {
				p.setFirstname(br.readLine());
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		    
		    System.out.println("Enter the last name:");
		    try {
				p.setLastname(br.readLine());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    System.out.println("Enter gender name:");
		    try {
				p.setGender((char)br.read());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    System.out.println(p);
	}
}



package com.lab;

import java.util.ArrayList;
import java.util.Scanner;

public class Lab7_2 {
	
	
	public ArrayList<String>stringFunctions(String str1,String str2){
		
		ArrayList<String> a1=new ArrayList<String>();
		int len1=str1.length();
		int len2=str2.length();
		String temp="";
		//operation1
		int i=0,j=0,flag=0;
		for(i=0;i<len1;i++) {
			if(i%2==0) {
				temp=temp+str1.charAt(i);
			}else {
				if(j<len2) {
					temp=temp+str2.charAt(j);
					j++;
				}else {
					flag=1;
					break;
				}
			}
		}
		for(j=i;j<len1;j++) {
			temp=temp+str1.charAt(j);
		}
		a1.add(temp);
		
		//operation2
		temp="";
		String reverse="";
		int f=str1.lastIndexOf(str2);
		if(f==-1) {
			a1.add(str1+str2);
		}else
		{
			for(i=0;i<f;i++) {
				temp=temp+str1.charAt(i);
			}
			for(j=str2.length()-1;j>=0;j--) {
				temp=temp+str2.charAt(j);
			}
			for(j=i+len2;j<len1;j++) {
				temp=temp+str1.charAt(j);
			}
			a1.add(temp);
		}
		//operation3
		temp="";
		f=str1.lastIndexOf(str2);
		if(f==-1) {
			a1.add(str1);
		}
		else {
			for(i=0;i<f;i++) {
				temp=temp+str1.charAt(i);
		}
			for(j=str2.length()-1;j>=0;j--) {
				temp=temp+str2.charAt(j);
			}
			for(j=i+len2;j<len1;j++) {
				temp=temp+str1.charAt(j);
			}
			a1.add(temp);
			
		}
		//operation4
		temp="";
		if(len2%2==0) {
			temp=temp+str2.substring(0, len2/2);
			temp=temp+str1;
			temp=temp+str2.substring(len2/2,len2);
		}else { 
			temp=temp+str2.substring(0, len2/2 + 1);
			temp=temp+str1;
			temp=temp+str2.substring(len2/2 + 1,len2);
		}
		a1.add(temp);
		//Operation5
		temp="";
		for(i=0;i<len1;i++) {
			flag=0;
			for(j=0;j<len2;j++) {
				if(str1.charAt(i)==str2.charAt(j)) {
					flag=1;
					break;
				}
			}
			if(flag==1) {
				temp=temp+"";
				
			}else {
				temp=temp=temp+str1.charAt(i);
			}
		}
		a1.add(temp);
		
		return a1;
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Lab7_2 so=new Lab7_2();
		System.out.println("enter the first string");
		String str1=sc.next();
		System.out.println("enter the second string");
		String str2=sc.next();
		ArrayList<String> str;
		str=so.stringFunctions(str1,str2);
		System.out.println(str);
	}

}

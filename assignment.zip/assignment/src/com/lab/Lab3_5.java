package com.lab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Lab3_5 {
public static void main(String[] args)
{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("enter start date and warranty period");
	String str;
	try {
		str =br.readLine();
		int wrr=Integer.parseInt(br.readLine());
		LocalDate d=m1(str,wrr);
		 DateTimeFormatter  format= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println(d.format(format));
}
	catch(IOException e) {
		e.printStackTrace();
	}
}
	
	public static LocalDate m1(String str,int wrr) {
		 DateTimeFormatter  format= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate p=LocalDate.parse(str,format);
		p=p.plusMonths(wrr);
		return p;
	}
}

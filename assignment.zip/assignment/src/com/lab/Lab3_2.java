package com.lab;

public class Lab3_2 {
  static int flag;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
              String str=new String();
              str="pavan";
              str=str.toUpperCase();
              System.out.println(m(str));
	}
	  public static boolean m(String str1) {
		  for(int i=0;i<str1.length();i++) {
			  for(int j=i+1;j<str1.length();j++) {
				  if((int)str1.charAt(i)>(int)str1.charAt(j)) {
					  flag=1;
				  }
				  
			  }
		  }
		  if(flag==0) {
			  return true;
		  }
		  else
			  return false;
	  }

}

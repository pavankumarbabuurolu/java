package com.lab;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Lab3_3 {
	 

	private static Scanner sc;
	public static void main(String[] args) {
		sc = new Scanner(System.in);
           System.out.println("Enter the date");
           String str=sc.next();
           Lab3_3  dt=new Lab3_3();
           System.out.println("years  "+dt.m1(str).getYears());
           System.out.println("months  "+dt.m1(str).getMonths());
           System.out.println("days  "+dt.m1(str).getDays());
           
	}
 public  Period m1(String str) {
	 DateTimeFormatter  format= DateTimeFormatter.ofPattern("dd/MM/yyyy");
	 LocalDate start=LocalDate.parse(str, format);
	 LocalDate present=LocalDate.now();
	 Period period=start.until(present);
	 return period;
 }
}

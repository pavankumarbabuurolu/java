package com.lab;

public class Lab2_4 {
	private String firstname;
	private String lastname;
	   private char gender;
	   String phonenumber;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	   
	@Override
	public String toString() {
		System.out.println("Person Details:");
		System.out.println("");
		System.out.println("____________");
		System.out.println("");
		System.out.println("First Name:"+firstname );
		System.out.println("Last Name:"+lastname);
		System.out.println("Gender:"+gender);
		System.out.println("Phonenumber:"+phonenumber);
		
		 return "";
	}
}

package com.lab;

import java.util.Scanner;

public class Lab3_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the username:");
		String s=sc.next();
		System.out.println(m1(s));

	}
 public static 	  boolean  m1(String str) {
	    int len=str.length();
	  boolean  k=true,l=false;
	 if(  str.endsWith("_job")&&((len)-4>=8)) {
		 return k;
	 }
	 else
		 return l;
 }
}

package com.lab;

public class Lab2_2 {
	public static void main(String[] args) {
		int i=Integer.parseInt(args[0]);
		if(i>0) {
			System.out.println("number is positive"); 
			}
			else {
				System.out.println("number is negative");
			}
			
		}
	

}

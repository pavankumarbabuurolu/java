package com.lab;

import java.util.ArrayList;
import java.util.Scanner;

public class Lab7_3 {

	public static ArrayList<String> removeElements(ArrayList<String> list1,ArrayList<String> list2){
		list1.removeAll(list2);
		return list1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> li1=new ArrayList<String>();
ArrayList<String> li2=new ArrayList<String>();
ArrayList<String> li3=new ArrayList<String>();
System.out.println(li1.size());
      Scanner sc=new Scanner(System.in);
      int n=sc.nextInt();
      for(int i=0;i<n;i++) {
    	  li1.add((String)sc.next());
    	  }
    	  Scanner sc1=new Scanner(System.in);
          int n1=sc.nextInt();
          for(int i=0;i<n1;i++) {
        	  li2.add((String)sc.next());
     
      
	}
      li3=removeElements(li1,li2);
      System.out.println(li3);
}
	
}

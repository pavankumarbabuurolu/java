package com.lab;

import java.util.Scanner;

public class Lab3_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="pavanpaaa";
		System.out.println("Enter the key  1.Add   0000000000000000000000000000 2.Replace odd positions with #   3.emove duplicate    4.Change odd characters to upper case");
		Scanner sc=new Scanner(System.in);
		int key=sc.nextInt();
		
		
  switch (key) {
case 1:   
	   System.out.println(m1(str));
	break;
case 2:
	System.out.println(m2(str));
	break;
case 3:
	System.out.println(m3(str));
	break;
case 4:
	System.out.println(m4(str));
	break;

default:
	break;
}

	}

	public static String m1(String str) {
	 	str=str+str;
	 	return str;
	}
	
	
	public static String m2(String str) {
		System.out.println(str);
		
		StringBuffer sb=new StringBuffer(str);
			for(int i=0;i<sb.length();i+=2) {
				sb.setCharAt(i,'#');
			
			
		}
		String sr=new String(sb);
		return sr;
	}
	public static String m3(String str) {
		StringBuffer sb=new StringBuffer(str);
		System.out.println(str);
		for(int i=0;i<sb.length();i++) {
			for(int j=i+1;j<sb.length();j++)
			if(i==sb.length())
				break;
			else if(sb.charAt(i)==sb.charAt(j)) {
				sb.deleteCharAt(j);
				j--;
			}
		}
		String sh=new String(sb);
		return sh;
	}
	
	public static String m4(String str) {
System.out.println(str);
		
		StringBuffer sb=new StringBuffer(str);
			for(int i=0;i<sb.length();i+=2) {
				sb.setCharAt(i, (char)(sb.charAt(i)-32));
			
			
		}
		String sr=new String(sb);
		return sr;
		
		
	    }
}


	    

	
	

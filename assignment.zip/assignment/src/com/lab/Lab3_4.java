package com.lab;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Lab3_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Scanner sc=new Scanner(System.in);
         System.out.println("enter start date");
         String str1=sc.next();
         System.out.println("enter end date");
         String str2=sc.next();
         Lab3_4 lb=new Lab3_4();
         System.out.println("years  "+lb.m1(str1,str2).getYears());
         System.out.println("months  "+lb.m1(str1,str2).getMonths());
         System.out.println("days  "+lb.m1(str1,str2).getDays());
         
         
	}
	public  Period m1(String str1,String str2) {
		 DateTimeFormatter  format= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		 LocalDate start=LocalDate.parse(str1, format);
		 LocalDate end=LocalDate.parse(str2, format);
		 Period period=start.until(end);
		 return period;
}
}
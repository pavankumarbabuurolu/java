package com.lab;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class Lab3_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          
		Scanner sc=new Scanner(System.in);
		System.out.println("Eneter the zone");
		String str=sc.next();
		System.out.println(m1(str));
	}
public  static ZonedDateTime m1(String str) {
	
	ZonedDateTime currentTime = ZonedDateTime.now();
	ZonedDateTime currentTime1 = ZonedDateTime.now(ZoneId.of(str));
	return currentTime1;
}
}

package com.lab;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Lab7_4 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int k=sc.nextInt();
		ArrayList<Integer> li=new ArrayList<Integer>();
		for(int i=0;i<k;i++) {
			li.add(sc.nextInt());
		}
			
       Iterator<Integer> it=li.iterator();
       while (it.hasNext()) {
		int  x=it.next();
		int y=x*x;
		metho(x,y);
	}
	}
public static int metho(int k,int l) {
	Map<Integer,Integer> m=new HashMap<Integer,Integer>();
	m.put(k, l);
	System.out.println(m);
	return 0;
}
}

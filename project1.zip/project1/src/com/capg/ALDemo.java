package com.capg;
import java.util.ArrayList;
public class ALDemo {
	public static void main(String[] args) {
		
		
		
		ArrayList<integer> list=new Array<Integer>();
	}

}

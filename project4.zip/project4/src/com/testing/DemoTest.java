package com.testing;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class DemoTest {

	@Test
	public void testGetData() {
		//assertEquals("king",Demo.getData() );
		
		assertNotNull(Demo.getData());
	}
		

	@Test
	@Ignore
	public void testGetNum() {
		fail("Not yet implemented");
	}

}

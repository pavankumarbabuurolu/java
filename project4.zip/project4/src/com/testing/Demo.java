package com.testing;

public class Demo {
	public  static String getData() {
		return "king";
	}
	public static int getNum() {
		return 99;
	}

}

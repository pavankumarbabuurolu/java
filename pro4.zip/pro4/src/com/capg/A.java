package com.capg;

public class A {

}

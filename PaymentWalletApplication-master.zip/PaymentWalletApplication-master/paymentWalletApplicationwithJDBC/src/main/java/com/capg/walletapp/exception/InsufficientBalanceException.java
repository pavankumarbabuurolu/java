package com.capg.walletapp.exception;

public class InsufficientBalanceException extends Exception {

}

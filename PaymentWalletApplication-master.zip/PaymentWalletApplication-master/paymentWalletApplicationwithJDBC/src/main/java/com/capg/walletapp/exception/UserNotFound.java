package com.capg.walletapp.exception;

public class UserNotFound extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}

package com.capg.walletapp.dao;

import com.capg.walletapp.bean.WalletApplication;

public class WalletApplicationDao implements IWalletApplicationDao {

	public int createAcc(WalletApplication bean) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean login(String username, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	public double showBal() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deposit(double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int withdraw(double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int fundTransfer(long accNum, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	public WalletApplication printTrans(long tID) {
		// TODO Auto-generated method stub
		return null;
	}

}

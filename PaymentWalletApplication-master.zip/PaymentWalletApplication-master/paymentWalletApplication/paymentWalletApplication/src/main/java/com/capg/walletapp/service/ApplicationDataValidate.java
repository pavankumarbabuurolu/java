package com.capg.walletapp.service;

public class ApplicationDataValidate {

	public boolean validateAge(int age) {
		
		return false;
	}
	public boolean validateMail(String email) {
		
		return false;
	}
	public boolean validateUsername(String username) {
		
		return false;
	}
	public boolean validatePassword(String password) {
		
		return false;
	}
	public boolean validateContact(String contact) {
		
		return false;
	}
	public boolean validateGender(String gender) {
		
		return false;
	}
	public boolean validateAmount(double amount) {
		
		return false;
	}
	public boolean validateCustomerName(String customerName) {
		
		return false;
	}
	
}

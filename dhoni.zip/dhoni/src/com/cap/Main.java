package com.cap;

public class Main {

	public static void main(String[] args) {
		
		Employee e1= new Employee();
            
		   e1.setEid(101);
		   e1.setEname("scott");
		   e1.setSal(22222);
		   System.out.println(e1);
		   e1.
	}

}

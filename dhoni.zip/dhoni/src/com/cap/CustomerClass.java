package com.cap;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CustomerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("welcome");
		System.out.println("name");
		  Customer c=new Customer();
		

	}

}

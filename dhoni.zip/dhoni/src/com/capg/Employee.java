package com.capg;

public class Employee {

	 private int eid=101;
	
	private String ename="pavan";
	 
	 private int sal=55555;



	public int getEid() {
		return eid;
	}

	public String getEname() {
		return ename;
	}

	public int getSal() {
		return sal;
	}
	 
	
}

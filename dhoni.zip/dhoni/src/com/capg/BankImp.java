package com.capg;

public class BankImp implements Bank{
	
	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		
	}

}

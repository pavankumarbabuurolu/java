package com.capg;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Employee e1= new Employee();
	System.out.println(e1.getEid());
	System.out.println(e1.getEname());
	System.out.println(e1.getSal());
	

	}

}

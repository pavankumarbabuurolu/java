package com.capg;

public class Demo {
	
	static int eid;
	static  String ename;
	
	public static void main(String[] args) {
		final int x;
		
		System.out.println("welcome to java");
		Demo d=new Demo();
		System.out.println(d.eid);
		System.out.println(d.ename);
	}

}

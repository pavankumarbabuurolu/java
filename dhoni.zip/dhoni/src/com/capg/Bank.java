package com.capg;

public interface Bank {
	
	void deposit();

}

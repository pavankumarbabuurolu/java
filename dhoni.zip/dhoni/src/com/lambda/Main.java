package com.lambda;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		CalculatorInterface ci= (e,r) -> (e=r);
System.out.println(ci.fun("heloo"));
	}

}

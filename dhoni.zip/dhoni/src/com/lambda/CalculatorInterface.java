package com.lambda;
@FunctionalInterface

public interface CalculatorInterface {
	
	 int fun(Integer x,Integer y);

}

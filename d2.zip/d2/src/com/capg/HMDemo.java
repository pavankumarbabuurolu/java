package com.capg;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class HMDemo {
	public static void main(String[] args)
	{	
		
		
		Map<Integer,Object> m=new TreeMap<Integer,Object>();
	
	Integer i1=new Integer(6);
	Integer i2=new Integer(7);
	m.put(i1,"pavan");
	m.put(i2,7
			);
	System.out.println(m);
	
	Set st = m.keySet();
	 Iterator<Integer> it =st.iterator();
	 while (it.hasNext()) {
		int k=it.next();
		System.out.println(k);
		System.out.println(m.get(k));
		
	}

}
}
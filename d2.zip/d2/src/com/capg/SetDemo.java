package com.capg;

import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set<I
		nteger> st= new TreeSet<Integer>();
		
		
		st.add(1);
		System.out.println(st.add(5));
		st.add(2);
		System.out.println(st.add(2));
		System.out.println(st);
	}

}

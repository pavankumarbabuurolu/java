package com.capg;

import java.util.ArrayList;
import java.util.Iterator;

public class ALDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
		ArrayList<Integer> list=new ArrayList<Integer>();
		
		
		
		list.add(5);
		list.add(6);
		list.add(8);
		
		
		Iterator<Integer> it=list.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	System.out.println(list);
	
	for (Integer x : list) {
		System.out.println(x);
		
	}
	}
	

}
